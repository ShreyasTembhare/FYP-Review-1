import requests

city=input("Enter Your City --> ")
Api_Key = "2606f769271b8d545fe3458b2b72ed9f" # Paste Your API ID Here

final_URL = "http://api.openweathermap.org/data/2.5/weather?q={}&appid={}".format(city,Api_Key)

result = requests.get(final_URL)
data = result.json()

temprature = data['main']['temp']
cordinatelon = data['coord']['lon']
cordinatelat = data['coord']['lat']
humidity = data['main']['humidity']
rainfall = data['rain']['1h'] if 'rain' in data and '1h' in data['rain'] else 0




print("Temperature in {}: {} K".format(city, temprature))

print("Humidity: {}%".format(humidity))
print("Rainfall in the last hour: {} mm".format(rainfall))
#print("The temperature in", city, "is:", temprature)
#print(temprature," ",cordinatelat," ",cordinatelon)


